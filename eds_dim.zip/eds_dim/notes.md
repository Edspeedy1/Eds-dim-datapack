*add to ice_fields.json*
- terrain
    \- noise 1
        - water
        - ice
        - packed_ice
        - snow
    \- noise 2
        - grass
        - stone
        - snow
    \- noise 3 ?
        - ice
        - packed_ice
        - grass
    - underground
        \- ceiling 1 block ice
        \- floor 1 block ice mix snow
        \- top stone: stone + diorite + calcite + andesite + bone
        \- bottom stone: blackstone + smooth basalt + packed_ice + bone
    
\- ice spikes
\- icey trees (brown mushroom spawning)
\- taiga big and small trees (less numbers and no dirt replacement and mangrove leaves)
